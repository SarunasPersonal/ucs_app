import 'package:flutter/material.dart';

const Color primaryColor = const Color(0xFFAD1E3C);
const Color secondaryColor = const Color(0xFFEECB28);
const Color whiteColor = Colors.white;